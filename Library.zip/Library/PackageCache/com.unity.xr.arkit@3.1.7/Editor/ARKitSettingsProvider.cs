using System;

namespace UnityEditor.XR.ARKit
{
    /// <summary>
    /// This class is now deprecated. Its internal functionality has been replaced by
    /// [XR Plug-in Management](https://docs.unity3d.com/Packages/com.unity.xr.management@3.2)
    /// </summary>
    [Obsolete("This class is now deprecated. Its internal functionality is replaced by XR Management")]
    public static class ARKitSettingsProvider
    {

    }
}
