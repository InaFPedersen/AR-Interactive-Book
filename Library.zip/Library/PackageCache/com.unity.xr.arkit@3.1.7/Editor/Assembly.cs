using System.Runtime.CompilerServices;

#if UNITY_EDITOR
[assembly: InternalsVisibleTo("Unity.XR.ARKit.FaceTracking.Editor")]
#endif
