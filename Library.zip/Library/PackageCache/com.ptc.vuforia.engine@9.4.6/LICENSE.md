** Vuforia Engine **

Copyright (c) 2010-2019 PTC Inc.
All Rights Reserved.

To view the Vuforia Developer Agreement, go to: https://developer.vuforia.com/legal/vuforia-developer-agreement
3rd party notices can be found under the Vuforia/Editor/EditorResources/Licenses folder of this package.