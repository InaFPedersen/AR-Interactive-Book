using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.XR.ARFoundation.Runtime.Tests")]
